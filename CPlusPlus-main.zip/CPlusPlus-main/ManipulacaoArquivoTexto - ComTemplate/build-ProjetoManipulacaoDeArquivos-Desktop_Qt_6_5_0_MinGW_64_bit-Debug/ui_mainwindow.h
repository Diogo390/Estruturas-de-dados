/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 6.5.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTableWidget>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QTextEdit *textEditSaida;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButtonAbrirArquivo;
    QPushButton *pushButtonCriarNovoArquivo;
    QPushButton *pushButtonIncluirNoFinal;
    QPushButton *pushButtonLimparCaixa;
    QComboBox *comboBox_Ordem;
    QPushButton *pushButton_Ordenar;
    QTableWidget *tableWidget_SaidaGrid;
    QComboBox *comboBox_NomesOUNumeros;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName("MainWindow");
        MainWindow->resize(658, 606);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName("centralWidget");
        textEditSaida = new QTextEdit(centralWidget);
        textEditSaida->setObjectName("textEditSaida");
        textEditSaida->setGeometry(QRect(10, 80, 441, 161));
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName("layoutWidget");
        layoutWidget->setGeometry(QRect(10, 10, 659, 32));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName("horizontalLayout");
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButtonAbrirArquivo = new QPushButton(layoutWidget);
        pushButtonAbrirArquivo->setObjectName("pushButtonAbrirArquivo");

        horizontalLayout->addWidget(pushButtonAbrirArquivo);

        pushButtonCriarNovoArquivo = new QPushButton(layoutWidget);
        pushButtonCriarNovoArquivo->setObjectName("pushButtonCriarNovoArquivo");

        horizontalLayout->addWidget(pushButtonCriarNovoArquivo);

        pushButtonIncluirNoFinal = new QPushButton(layoutWidget);
        pushButtonIncluirNoFinal->setObjectName("pushButtonIncluirNoFinal");

        horizontalLayout->addWidget(pushButtonIncluirNoFinal);

        pushButtonLimparCaixa = new QPushButton(layoutWidget);
        pushButtonLimparCaixa->setObjectName("pushButtonLimparCaixa");

        horizontalLayout->addWidget(pushButtonLimparCaixa);

        comboBox_Ordem = new QComboBox(centralWidget);
        comboBox_Ordem->addItem(QString());
        comboBox_Ordem->addItem(QString());
        comboBox_Ordem->setObjectName("comboBox_Ordem");
        comboBox_Ordem->setGeometry(QRect(470, 120, 151, 31));
        pushButton_Ordenar = new QPushButton(centralWidget);
        pushButton_Ordenar->setObjectName("pushButton_Ordenar");
        pushButton_Ordenar->setGeometry(QRect(490, 180, 111, 61));
        tableWidget_SaidaGrid = new QTableWidget(centralWidget);
        if (tableWidget_SaidaGrid->columnCount() < 2)
            tableWidget_SaidaGrid->setColumnCount(2);
        QTableWidgetItem *__qtablewidgetitem = new QTableWidgetItem();
        tableWidget_SaidaGrid->setHorizontalHeaderItem(0, __qtablewidgetitem);
        QTableWidgetItem *__qtablewidgetitem1 = new QTableWidgetItem();
        tableWidget_SaidaGrid->setHorizontalHeaderItem(1, __qtablewidgetitem1);
        tableWidget_SaidaGrid->setObjectName("tableWidget_SaidaGrid");
        tableWidget_SaidaGrid->setGeometry(QRect(180, 260, 301, 251));
        tableWidget_SaidaGrid->horizontalHeader()->setDefaultSectionSize(149);
        comboBox_NomesOUNumeros = new QComboBox(centralWidget);
        comboBox_NomesOUNumeros->addItem(QString());
        comboBox_NomesOUNumeros->addItem(QString());
        comboBox_NomesOUNumeros->setObjectName("comboBox_NomesOUNumeros");
        comboBox_NomesOUNumeros->setGeometry(QRect(470, 80, 151, 31));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName("menuBar");
        menuBar->setGeometry(QRect(0, 0, 658, 20));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName("mainToolBar");
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName("statusBar");
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        pushButtonAbrirArquivo->setText(QCoreApplication::translate("MainWindow", "Abrir Arquivo", nullptr));
        pushButtonCriarNovoArquivo->setText(QCoreApplication::translate("MainWindow", "Criar Novo Arquivo", nullptr));
        pushButtonIncluirNoFinal->setText(QCoreApplication::translate("MainWindow", "Incluir no Final do Arquivo", nullptr));
        pushButtonLimparCaixa->setText(QCoreApplication::translate("MainWindow", "Limpar Caixa de Texto", nullptr));
        comboBox_Ordem->setItemText(0, QCoreApplication::translate("MainWindow", "OrdemCrescente", nullptr));
        comboBox_Ordem->setItemText(1, QCoreApplication::translate("MainWindow", "OrdemDecrescente", nullptr));

        pushButton_Ordenar->setText(QCoreApplication::translate("MainWindow", "Ordenar", nullptr));
        QTableWidgetItem *___qtablewidgetitem = tableWidget_SaidaGrid->horizontalHeaderItem(0);
        ___qtablewidgetitem->setText(QCoreApplication::translate("MainWindow", "Matr\303\255cula", nullptr));
        QTableWidgetItem *___qtablewidgetitem1 = tableWidget_SaidaGrid->horizontalHeaderItem(1);
        ___qtablewidgetitem1->setText(QCoreApplication::translate("MainWindow", "Nome", nullptr));
        comboBox_NomesOUNumeros->setItemText(0, QCoreApplication::translate("MainWindow", "Nomes", nullptr));
        comboBox_NomesOUNumeros->setItemText(1, QCoreApplication::translate("MainWindow", "Matriculas", nullptr));

    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
